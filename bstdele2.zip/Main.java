public class Main
{
    static class  node 
    {
        int data;
        node L,R;
        node(int d)
        {
            data=d;
            L=null;
            R=null;
        }
    }
static node ins(node r,int d)
{
    if(r==null)
    {
    r=new node(d);
    return r;
    }
        if(d<r.data)
        r.L=ins(r.L,d);
        else if(d>r.data)
        r.R=ins(r.R,d);
    return r;
}
static void inorder(node temp)
{
    if (temp == null)
    return;
    inorder(temp.L);
    System.out.print(temp.data + " ");
    inorder(temp.R);
}
static node del(node root,int k)
{
if (root==null)
return root;
if (k<root.data)
root.L = del(root.L,k);
else if (k>root.data)
root.R= del(root.R,k);
else {
if (root.L==null)
return root.R;
else if (root.R==null)
return root.L;
root.data = replace(root.R);
root.R= del(root.R,root.data);
}
return root;
} 
static int replace(node root) {
int val = root.data;
while (root.L!=null) {
val = root.L.data;
root = root.L;
}
return val;
}

public static void main(String[] args) {
    node root=null;
	node t=ins(root,12);
	ins(t,22);
	ins(t,17);
	ins(t,2);
	ins(t,1);
	ins(t,7);
	inorder(t);
	del(t,2);
	System.out.println("\nAfter delete");
	inorder(t);
	}
}
