import java.util.*;
public class Main
{
    static class node 
    {
        int data;
        node next;
        node(int d)
        {
            data=d;
            next=null;
        }
    }
    static node head=null;
    static void add(int d)
    {
        node n=new node(d);
        if(head==null)
        head=n;
        else
        {
            node temp=head;
            while(temp.next!=null)
            temp=temp.next;
            temp.next=n;
        }
    }
    static void Blist()
    {
        node temp=head;
        node temp1=head;
        int c=0,l=0,r=0;
        while(temp!=null)
        {
            c++;
            temp=temp.next;
        }
        for(int i=0;i<c/2;i++)
        {
            l+=temp1.data;
            temp1=temp1.next;
        }
        for(int i=c/2;i<c;i++)
        {
            r+=temp1.data;
            temp1=temp1.next;
        }
        System.out.println(l==r?"BList":Math.abs(l-r));
    }
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    while(s.hasNextInt())
	    add(s.nextInt());
	    Blist();
	}
}
