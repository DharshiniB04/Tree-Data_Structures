


boolean FullBTree(Node root){
    if(root!=null){
        if(root.left == null && root.right == null)
        return true;
        if((root.left!=null)&&(root.right!=null))
        return(FullBTree(root.left)&&FullBTree(root.right))
        return false;
    }
}