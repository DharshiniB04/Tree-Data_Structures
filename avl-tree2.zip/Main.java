import java.util.*;
class BST{
  node root;
   class node{
    int data,height;
    node left,right;
    node(int val){
      data=val;height=0;
      left=right=null;
    }
  }
int get(node r){
    if(r==null)
    return -1;
    return r.height;
  }
  int findb(node root){
     return get(root.left)-get(root.right);
   }
void insert(int val){
     root=ins(root,val);
   }
node ins(node root,int key){
     if(root==null){
       root=new node(key);
       return root;
     }
     if(key>root.data){
       root.right=ins(root.right,key);
     }
     else if(key<root.data)
     root.left=ins(root.left,key);
     else 
     return root;
    root.height=1+Math.max(get(root.left),get(root.right));
    System.out.println(root.data+" "+"the height is "+":"+root.height);
    int bfactor=findb(root);
    System.out.println(root.data+" "+"the F actor is :"+""+bfactor);
    if(bfactor>1&&key<root.left.data)
    return rotateRight(root);
    if(bfactor>1&&key>root.left.data)
    {
      root.left=rotateLeft(root.left);
      return rotateRight(root);
    }
    if(bfactor<-1&&key>root.right.data)
    return rotateLeft(root);
    if(bfactor<-1&&key<root.right.data)
      { root.right=rotateRight(root.right);
      return rotateLeft(root);
      }
     return root;
   }
node rotateRight(node z){
     node y=z.left;
     node temp=y.right;
       y.right=z;
       z.left=temp;
       z.height=1+Math.max(get(z.left),get(z.right));
       y.height=1+Math.max(get(y.left),get(y.right));
       return y;
   }
node rotateLeft(node z){
     node y=z.right;
     node t1=y.left;
       y.left=z;
       z.right=t1;
       z.height=1+Math.max(get(z.left),get(z.right));
       y.height=1+Math.max(get(y.left),get(y.right));
       return y;
   }
node inorder(node root)
{
    if(root==null)
    return root;
    inorder(root.left);
    System.out.print(root.data+" ");
    inorder(root.right);
    return root;
}
}
public class Main {
    public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    BST b=new BST();
    b.insert(7);
    b.insert(9);
    b.insert(8);
    b.insert(6);
    b.insert(1);
     b.inorder(b.root);  
  }
}