import java.util.*;
public class Main
{
  static class node
  {
    int data;
    node L, R;
      node (int d)
    {
      data = d;
      L = null;
      R = null;
    }
  }
  static node ins (node r, int d)
  {
    if (r == null)
      {
	r = new node (d);
	return r;
      }
    if (d < r.data)
      r.L = ins (r.L, d);
    else if (d > r.data)
      r.R = ins (r.R, d);
    return r;
  }
static void search(node root,int k)
{
    if(root==null)
    System.out.println("no");
    else if(k<root.data)
    search(root.L,k);
    else if(k>root.data)
    search(root.R,k);
    else
    System.out.println("yes");
}
  static void inorder (node temp)
  {
    if (temp == null)
      return;
    inorder (temp.L);
    System.out.print (temp.data + " ");
    inorder (temp.R);
  }
  public static void main (String[]args)
  {
    Scanner s = new Scanner (System.in);
    node root = null;
    System.out.println ("Enter root node:");
    node t = ins (root, s.nextInt ());
    System.out.println ("Enter node values:\nEnter -1 to exit");
    int a = s.nextInt ();
    while (a != -1)
      {
	ins (t, a);
	a = s.nextInt ();
	  }
    inorder (t);
    System.out.println ("\nEnter a value to search: ");
    int n = s.nextInt ();
    
    search (t, n);
  }
}
