public class Main
{
    static class  node 
    {
        int data;
        node L,R;
        node(int d)
        {
            data=d;
            L=null;
            R=null;
        }
    }
    static boolean S_B_T(node r)
    {
    if (r==null||(r.L== null&&r.R==null))
        return true;
    if (r.L!=null&&r.R!=null)
        return false;
    if (r.L!=null)
        return S_B_T(r.L);
    return S_B_T(r.R);
    }
    static node root=null;
	public static void main(String[] args) {
		root=new node(1);
		root.L=new node(2);
		root.L.L=new node(3);
		root.L.L.L=new node(4);
		System.out.println(S_B_T(root)?"yes":"no");
	}
}
