import java.util.*;
public class Main
{
    static class node 
    {
        int data;
        node R;
        node L;
        node(int d)
        {
            data=d;
            L=null;
            R=null;
        }
    }
    static node root=null;
    static int depth(node r)
    {
        if(r==null)
        return 0;
        return (1+depth(r.L)+depth(r.R));
    }
    static boolean iscmpt(node r,int d,int level)
    {
        if(r==null)
        return true;
        if (level >=d)
        return false;
        return (iscmpt(r.L,d,2*level+ 1)&&iscmpt(r.R,d,2*level+2));
    }
	public static void main(String[] args) {
	    root=new node(1);
	    root.L=new node(2);
	    root.R=new node(3);
	    root.L.L=new node(4);
	    root.L.R=new node(5);
	    root.R.L=new node(6);
	    root.R.R=new node(7);
	    int d=depth(root);
	    System.out.println(iscmpt(root,d,0)?"is C_B_TREE":"is Not C_B_TREE");
			}
}
