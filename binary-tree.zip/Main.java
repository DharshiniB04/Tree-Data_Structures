import java.util.*;
public class Main
{
    static class node 
    {
        int data;
        node R;
        node L;
        node(int d)
        {
            data=d;
            L=null;
            R=null;
        }
    }
    static node root=null;
    static node tempL=null;
    static node tempR=null;
    static void addL(int d)
    {
        Scanner s=new Scanner(System.in);
        if(tempL.L==null){
        tempL.L=new node(d);
        }
        else
        {
        System.out.println("Enter the side\n 1-L\n 2-R");
	    int k=s.nextInt();
         if(k==1)
        {
            while(tempL.L!=null)
            tempL=tempL.L;
            tempL.L=new node(d);
        }
        else
        {
            while(tempL.R!=null)
            tempL=tempL.R;
            tempL.R=new node(d);
        }
        }
    }
    static void addR(int d)
    {
        Scanner s=new Scanner(System.in);
        if(tempR.R==null){
        tempR.R=new node(d);
        }
        else
        {
        System.out.println("Enter the side\n 1-L\n 2-R");
	    int  k=s.nextInt();

        if(k==1)
        {
            while(tempR.L!=null)
            tempR=tempR.L;
            tempR.L=new node(d);
        }
        else
        {
            while(tempR.R!=null)
            tempR=tempR.R;
            tempR.R=new node(d);
        }
        }
    }
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    System.out.println("Enter the root");
	    int a=s.nextInt();
        root=new node(a);
        tempL=root;
        tempR=root;
	    while(a!=0)
	    {
	       System.out.println("Enter the value"); 
	       a=s.nextInt();
	       System.out.println("Enter the side\n 1-L\n 2-R \n 0-Break");
	       int p=s.nextInt();
	       switch(p)
	       {
	           case 1:
	           addL(a);
	           break;
	           case 2:
	           addR(a);
	           break;
	           case 0:
	           a=0;
	       }
	       
	    }
		System.out.println(root.data);
		System.out.println(root.L.data);
		System.out.println(root.R.data);
		System.out.println(root.L.L.data);
		System.out.println(root.L.R.data);
	}
}
