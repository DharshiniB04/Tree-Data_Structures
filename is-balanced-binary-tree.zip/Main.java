public class Main
{
    static class  node 
    {
        int data;
        node L,R;
        node(int d)
        {
            data=d;
            L=null;
            R=null;
        }
    }
    static node root=null;
    static class Height {
      int height;
      Height()
      {
          height=0;
      }
    }
static boolean checkHeightBalance(node root,Height height) {
    if (root == null) {
     height.height = 0;
    return true;
    }
    Height leftHeight_a = new Height(), 
    rightHeight_a = new Height();
    boolean l = checkHeightBalance(root.L, leftHeight_a);
    boolean r = checkHeightBalance(root.R, rightHeight_a);
    int leftHeight = leftHeight_a.height, 	rightHeight = rightHeight_a.height;
    height.height = (leftHeight > rightHeight ? leftHeight : rightHeight) + 1;
    if ((leftHeight - rightHeight >= 2) || (rightHeight - leftHeight >= 2))
    return false;
    else
    return l && r;
    }	
public static void main(String[] args) {
		root=new node(1);
		root.L=new node(2);
		root.R=new node(3);
		root.L.L=new node(4);
		root.L.R=new node(5);
		Height h=new Height();
		System.out.println(checkHeightBalance(root,h)?"yes":"no");
	}
}
